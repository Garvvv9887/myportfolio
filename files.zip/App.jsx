import { useState, useEffect, useRef, useCallback } from "react";

// ─── THREE.JS PARTICLE CANVAS ────────────────────────────────────────────────
function ParticleCanvas() {
  const canvasRef = useRef(null);
  const animRef = useRef(null);
  const particlesRef = useRef([]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");

    const resize = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    };
    resize();
    window.addEventListener("resize", resize);

    const COUNT = window.innerWidth < 768 ? 50 : 100;
    particlesRef.current = Array.from({ length: COUNT }, () => ({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      vx: (Math.random() - 0.5) * 0.4,
      vy: (Math.random() - 0.5) * 0.4,
      r: Math.random() * 1.5 + 0.5,
      alpha: Math.random() * 0.5 + 0.2,
    }));

    const mouse = { x: -9999, y: -9999 };
    const onMouse = (e) => {
      const rect = canvas.getBoundingClientRect();
      mouse.x = e.clientX - rect.left;
      mouse.y = e.clientY - rect.top;
    };
    canvas.addEventListener("mousemove", onMouse);

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const pts = particlesRef.current;

      pts.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1;

        // Mouse repulsion
        const dx = p.x - mouse.x;
        const dy = p.y - mouse.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 100) {
          p.x += (dx / dist) * 1.2;
          p.y += (dy / dist) * 1.2;
        }

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(99,102,241,${p.alpha})`;
        ctx.fill();
      });

      // Lines between nearby particles
      for (let i = 0; i < pts.length; i++) {
        for (let j = i + 1; j < pts.length; j++) {
          const dx = pts[i].x - pts[j].x;
          const dy = pts[i].y - pts[j].y;
          const d = Math.sqrt(dx * dx + dy * dy);
          if (d < 120) {
            ctx.beginPath();
            ctx.moveTo(pts[i].x, pts[i].y);
            ctx.lineTo(pts[j].x, pts[j].y);
            ctx.strokeStyle = `rgba(99,102,241,${0.15 * (1 - d / 120)})`;
            ctx.lineWidth = 0.5;
            ctx.stroke();
          }
        }
      }

      animRef.current = requestAnimationFrame(draw);
    };
    draw();

    return () => {
      cancelAnimationFrame(animRef.current);
      window.removeEventListener("resize", resize);
      canvas.removeEventListener("mousemove", onMouse);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: "absolute",
        inset: 0,
        width: "100%",
        height: "100%",
        pointerEvents: "auto",
      }}
    />
  );
}

// ─── FLOATING 3D GEOMETRY ─────────────────────────────────────────────────────
function FloatingOrb({ size, top, left, delay, color }) {
  return (
    <div
      style={{
        position: "absolute",
        top,
        left,
        width: size,
        height: size,
        borderRadius: "50%",
        background: `radial-gradient(circle at 35% 35%, ${color}40, ${color}05)`,
        border: `1px solid ${color}20`,
        animation: `floatOrb 6s ease-in-out infinite`,
        animationDelay: delay,
        filter: `blur(0.5px)`,
        pointerEvents: "none",
      }}
    />
  );
}

// ─── TILT CARD ────────────────────────────────────────────────────────────────
function TiltCard({ children, style }) {
  const cardRef = useRef(null);

  const handleMouseMove = useCallback((e) => {
    const card = cardRef.current;
    if (!card) return;
    const rect = card.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const rx = ((e.clientY - cy) / (rect.height / 2)) * 8;
    const ry = ((e.clientX - cx) / (rect.width / 2)) * -8;
    card.style.transform = `perspective(600px) rotateX(${rx}deg) rotateY(${ry}deg) scale(1.02)`;
  }, []);

  const handleMouseLeave = useCallback(() => {
    if (cardRef.current)
      cardRef.current.style.transform =
        "perspective(600px) rotateX(0deg) rotateY(0deg) scale(1)";
  }, []);

  return (
    <div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={{
        transition: "transform 0.15s ease",
        ...style,
      }}
    >
      {children}
    </div>
  );
}

// ─── MAGNETIC BUTTON ──────────────────────────────────────────────────────────
function MagneticBtn({ children, href, onClick, variant = "primary", style }) {
  const btnRef = useRef(null);

  const handleMouseMove = useCallback((e) => {
    const btn = btnRef.current;
    if (!btn) return;
    const rect = btn.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const dx = (e.clientX - cx) * 0.3;
    const dy = (e.clientY - cy) * 0.3;
    btn.style.transform = `translate(${dx}px, ${dy}px)`;
  }, []);

  const handleMouseLeave = useCallback(() => {
    if (btnRef.current) btnRef.current.style.transform = "translate(0,0)";
  }, []);

  const base = {
    display: "inline-flex",
    alignItems: "center",
    gap: "8px",
    padding: "12px 28px",
    borderRadius: "6px",
    fontFamily: "'Space Grotesk', sans-serif",
    fontWeight: 600,
    fontSize: "14px",
    letterSpacing: "0.02em",
    cursor: "pointer",
    transition: "transform 0.2s ease, box-shadow 0.2s ease, background 0.2s",
    border: "none",
    textDecoration: "none",
  };

  const variants = {
    primary: {
      background: "linear-gradient(135deg, #4F46E5, #7C3AED)",
      color: "#fff",
      boxShadow: "0 0 20px rgba(79,70,229,0.4)",
    },
    outline: {
      background: "transparent",
      color: "#CBD5E1",
      border: "1px solid rgba(99,102,241,0.4)",
      boxShadow: "none",
    },
  };

  const Tag = href ? "a" : "button";

  return (
    <Tag
      ref={btnRef}
      href={href}
      onClick={onClick}
      target={href ? "_blank" : undefined}
      rel={href ? "noopener noreferrer" : undefined}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={{ ...base, ...variants[variant], ...style }}
    >
      {children}
    </Tag>
  );
}

// ─── SKILL PILL ───────────────────────────────────────────────────────────────
function SkillPill({ label, icon }) {
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: "6px",
        padding: "6px 14px",
        borderRadius: "100px",
        fontSize: "13px",
        fontWeight: 500,
        color: "#A5B4FC",
        background: "rgba(79,70,229,0.12)",
        border: "1px solid rgba(99,102,241,0.25)",
        fontFamily: "'Space Grotesk', sans-serif",
        whiteSpace: "nowrap",
      }}
    >
      {icon && <span style={{ fontSize: "15px" }}>{icon}</span>}
      {label}
    </span>
  );
}

// ─── PROJECT CARD ─────────────────────────────────────────────────────────────
function ProjectCard({ title, desc, tags, link, index }) {
  const colors = ["#4F46E5", "#06B6D4", "#7C3AED", "#10B981"];
  const accent = colors[index % colors.length];

  return (
    <TiltCard
      style={{
        background: "rgba(15,23,42,0.85)",
        border: `1px solid rgba(255,255,255,0.06)`,
        borderRadius: "16px",
        padding: "28px",
        position: "relative",
        overflow: "hidden",
        backdropFilter: "blur(12px)",
        cursor: "pointer",
      }}
    >
      <div
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          height: "2px",
          background: `linear-gradient(90deg, transparent, ${accent}, transparent)`,
        }}
      />
      <div
        style={{
          width: "40px",
          height: "40px",
          borderRadius: "10px",
          background: `${accent}18`,
          border: `1px solid ${accent}30`,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: "18px",
          marginBottom: "16px",
        }}
      >
        ⬡
      </div>
      <h3
        style={{
          fontFamily: "'Space Grotesk', sans-serif",
          fontSize: "18px",
          fontWeight: 700,
          color: "#F1F5F9",
          margin: "0 0 10px",
        }}
      >
        {title}
      </h3>
      <p
        style={{
          fontFamily: "'Inter', sans-serif",
          fontSize: "14px",
          lineHeight: "1.65",
          color: "#94A3B8",
          margin: "0 0 20px",
        }}
      >
        {desc}
      </p>
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: "6px",
          marginBottom: "20px",
        }}
      >
        {tags.map((t) => (
          <span
            key={t}
            style={{
              padding: "3px 10px",
              borderRadius: "4px",
              fontSize: "11px",
              fontWeight: 600,
              color: accent,
              background: `${accent}15`,
              fontFamily: "'Space Grotesk', sans-serif",
              letterSpacing: "0.04em",
            }}
          >
            {t}
          </span>
        ))}
      </div>
      {link && (
        <a
          href={link}
          target="_blank"
          rel="noopener noreferrer"
          style={{
            fontSize: "13px",
            fontFamily: "'Space Grotesk', sans-serif",
            fontWeight: 600,
            color: accent,
            textDecoration: "none",
            display: "flex",
            alignItems: "center",
            gap: "4px",
          }}
        >
          View Project ↗
        </a>
      )}
    </TiltCard>
  );
}

// ─── SECTION HEADING ─────────────────────────────────────────────────────────
function SectionHeading({ label, title }) {
  return (
    <div style={{ marginBottom: "48px" }}>
      <p
        style={{
          fontFamily: "'Space Grotesk', sans-serif",
          fontSize: "12px",
          fontWeight: 600,
          letterSpacing: "0.12em",
          color: "#6366F1",
          textTransform: "uppercase",
          marginBottom: "10px",
        }}
      >
        {label}
      </p>
      <h2
        style={{
          fontFamily: "'Space Grotesk', sans-serif",
          fontSize: "clamp(28px, 4vw, 42px)",
          fontWeight: 800,
          color: "#F1F5F9",
          margin: 0,
          lineHeight: 1.15,
        }}
      >
        {title}
      </h2>
    </div>
  );
}

// ─── NAV ─────────────────────────────────────────────────────────────────────
function Navbar({ active }) {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const links = ["About", "Skills", "Projects", "Education", "Contact"];

  const scrollTo = (id) => {
    document.getElementById(id.toLowerCase())?.scrollIntoView({ behavior: "smooth" });
    setMenuOpen(false);
  };

  return (
    <>
      <nav
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          right: 0,
          zIndex: 100,
          padding: "0 5vw",
          height: "64px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          background: scrolled ? "rgba(5,11,24,0.92)" : "transparent",
          backdropFilter: scrolled ? "blur(20px)" : "none",
          borderBottom: scrolled ? "1px solid rgba(255,255,255,0.05)" : "none",
          transition: "all 0.3s ease",
        }}
      >
        <span
          style={{
            fontFamily: "'Space Grotesk', sans-serif",
            fontWeight: 800,
            fontSize: "20px",
            color: "#F1F5F9",
            letterSpacing: "-0.02em",
            cursor: "pointer",
          }}
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
        >
          GT<span style={{ color: "#6366F1" }}>.</span>
        </span>

        {/* Desktop nav */}
        <div
          className="desktop-nav"
          style={{ display: "flex", gap: "32px", alignItems: "center" }}
        >
          {links.map((l) => (
            <button
              key={l}
              onClick={() => scrollTo(l)}
              style={{
                background: "none",
                border: "none",
                color: active === l.toLowerCase() ? "#A5B4FC" : "#94A3B8",
                fontFamily: "'Space Grotesk', sans-serif",
                fontSize: "14px",
                fontWeight: 500,
                cursor: "pointer",
                padding: 0,
                transition: "color 0.2s",
              }}
            >
              {l}
            </button>
          ))}
          <MagneticBtn
            href="mailto:garvt957@gmail.com"
            variant="primary"
            style={{ padding: "8px 20px", fontSize: "13px" }}
          >
            Hire Me
          </MagneticBtn>
        </div>

        {/* Hamburger */}
        <button
          className="hamburger"
          onClick={() => setMenuOpen((p) => !p)}
          style={{
            background: "none",
            border: "1px solid rgba(99,102,241,0.3)",
            borderRadius: "8px",
            padding: "8px",
            cursor: "pointer",
            display: "none",
            flexDirection: "column",
            gap: "4px",
          }}
        >
          {[0, 1, 2].map((i) => (
            <span
              key={i}
              style={{
                display: "block",
                width: "20px",
                height: "2px",
                background: "#A5B4FC",
                borderRadius: "2px",
              }}
            />
          ))}
        </button>
      </nav>

      {/* Mobile menu */}
      {menuOpen && (
        <div
          style={{
            position: "fixed",
            top: "64px",
            left: 0,
            right: 0,
            zIndex: 99,
            background: "rgba(5,11,24,0.97)",
            backdropFilter: "blur(20px)",
            padding: "20px 5vw",
            borderBottom: "1px solid rgba(255,255,255,0.05)",
          }}
        >
          {links.map((l) => (
            <button
              key={l}
              onClick={() => scrollTo(l)}
              style={{
                display: "block",
                width: "100%",
                background: "none",
                border: "none",
                color: "#94A3B8",
                fontFamily: "'Space Grotesk', sans-serif",
                fontSize: "16px",
                fontWeight: 500,
                cursor: "pointer",
                padding: "14px 0",
                textAlign: "left",
                borderBottom: "1px solid rgba(255,255,255,0.04)",
              }}
            >
              {l}
            </button>
          ))}
        </div>
      )}
    </>
  );
}

// ─── CONTACT FORM ─────────────────────────────────────────────────────────────
function ContactForm() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [sent, setSent] = useState(false);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = (e) => {
    e.preventDefault();
    const subject = encodeURIComponent(`Portfolio Contact from ${form.name}`);
    const body = encodeURIComponent(`Name: ${form.name}\nEmail: ${form.email}\n\n${form.message}`);
    window.open(`mailto:garvt957@gmail.com?subject=${subject}&body=${body}`, "_blank");
    setSent(true);
    setTimeout(() => setSent(false), 3000);
  };

  const inputStyle = {
    width: "100%",
    background: "rgba(15,23,42,0.8)",
    border: "1px solid rgba(99,102,241,0.2)",
    borderRadius: "10px",
    padding: "14px 16px",
    color: "#F1F5F9",
    fontFamily: "'Inter', sans-serif",
    fontSize: "14px",
    outline: "none",
    boxSizing: "border-box",
    transition: "border-color 0.2s",
  };

  return (
    <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px" }} className="form-grid">
        <input
          name="name"
          placeholder="Your Name"
          value={form.name}
          onChange={handleChange}
          required
          style={inputStyle}
          onFocus={(e) => (e.target.style.borderColor = "rgba(99,102,241,0.6)")}
          onBlur={(e) => (e.target.style.borderColor = "rgba(99,102,241,0.2)")}
        />
        <input
          name="email"
          type="email"
          placeholder="Your Email"
          value={form.email}
          onChange={handleChange}
          required
          style={inputStyle}
          onFocus={(e) => (e.target.style.borderColor = "rgba(99,102,241,0.6)")}
          onBlur={(e) => (e.target.style.borderColor = "rgba(99,102,241,0.2)")}
        />
      </div>
      <textarea
        name="message"
        placeholder="Tell me about your project or opportunity..."
        value={form.message}
        onChange={handleChange}
        required
        rows={5}
        style={{ ...inputStyle, resize: "vertical" }}
        onFocus={(e) => (e.target.style.borderColor = "rgba(99,102,241,0.6)")}
        onBlur={(e) => (e.target.style.borderColor = "rgba(99,102,241,0.2)")}
      />
      <MagneticBtn
        onClick={handleSubmit}
        variant="primary"
        style={{ alignSelf: "flex-start", padding: "14px 32px" }}
      >
        {sent ? "✓ Sent!" : "Send Message"}
      </MagneticBtn>
    </form>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────
export default function App() {
  const [activeSection, setActiveSection] = useState("home");
  const [typedText, setTypedText] = useState("");
  const [cursorVisible, setCursorVisible] = useState(true);

  const roles = ["Web Developer.", "Frontend Dev.", "CS Student.", "Problem Solver."];
  const roleIndex = useRef(0);
  const charIndex = useRef(0);
  const deleting = useRef(false);

  // Typewriter
  useEffect(() => {
    const tick = () => {
      const current = roles[roleIndex.current];
      if (!deleting.current) {
        charIndex.current++;
        setTypedText(current.slice(0, charIndex.current));
        if (charIndex.current === current.length) {
          deleting.current = true;
          setTimeout(tick, 1800);
          return;
        }
      } else {
        charIndex.current--;
        setTypedText(current.slice(0, charIndex.current));
        if (charIndex.current === 0) {
          deleting.current = false;
          roleIndex.current = (roleIndex.current + 1) % roles.length;
        }
      }
      setTimeout(tick, deleting.current ? 60 : 100);
    };
    const t = setTimeout(tick, 400);
    return () => clearTimeout(t);
  }, []);

  // Cursor blink
  useEffect(() => {
    const t = setInterval(() => setCursorVisible((v) => !v), 530);
    return () => clearInterval(t);
  }, []);

  // Active section tracking
  useEffect(() => {
    const sections = ["about", "skills", "projects", "education", "contact"];
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) setActiveSection(e.target.id);
        });
      },
      { threshold: 0.5 }
    );
    sections.forEach((id) => {
      const el = document.getElementById(id);
      if (el) obs.observe(el);
    });
    return () => obs.disconnect();
  }, []);

  const projects = [
    {
      title: "Portfolio Website",
      desc: "This very portfolio — a custom-built React single-page app with 3D particle systems, magnetic buttons, and smooth scroll interactions. Deployed on Vercel with full SEO.",
      tags: ["React", "CSS3", "Vercel", "SEO"],
      link: "https://github.com/Garvvv9887",
    },
    {
      title: "Web App — Full Stack",
      desc: "A full-stack web application built with Node.js and PostgreSQL on the backend, featuring user authentication, RESTful APIs, and a clean responsive interface.",
      tags: ["Node.js", "PostgreSQL", "Express", "HTML/CSS"],
      link: "https://github.com/Garvvv9887",
    },
    {
      title: "SQL Dashboard",
      desc: "Data analysis dashboard connecting to a relational database, with dynamic queries, structured reporting, and a lightweight frontend for visualizing the output.",
      tags: ["SQL", "JavaScript", "PostgreSQL"],
      link: "https://github.com/Garvvv9887",
    },
    {
      title: "Responsive UI Kit",
      desc: "A collection of reusable responsive UI components built in plain HTML, CSS, and JavaScript — focused on accessibility and cross-browser compatibility.",
      tags: ["HTML", "CSS", "JavaScript"],
      link: "https://github.com/Garvvv9887",
    },
  ];

  const skillGroups = [
    {
      label: "Languages",
      skills: [
        { label: "HTML5", icon: "🌐" },
        { label: "CSS3", icon: "🎨" },
        { label: "JavaScript", icon: "⚡" },
        { label: "C", icon: "🔧" },
        { label: "C++", icon: "⚙️" },
        { label: "SQL", icon: "🗄️" },
      ],
    },
    {
      label: "Frontend",
      skills: [
        { label: "React", icon: "⚛️" },
        { label: "Responsive Design", icon: "📱" },
        { label: "CSS Animations", icon: "✨" },
      ],
    },
    {
      label: "Backend & Database",
      skills: [
        { label: "Node.js", icon: "🟢" },
        { label: "PostgreSQL", icon: "🐘" },
        { label: "SQL", icon: "🗃️" },
      ],
    },
    {
      label: "Tools & Infra",
      skills: [
        { label: "Git", icon: "📦" },
        { label: "GitHub", icon: "🐙" },
        { label: "VS Code", icon: "💻" },
        { label: "Vercel", icon: "▲" },
      ],
    },
  ];

  const certs = [
    { name: "JavaScript Algorithms", issuer: "freeCodeCamp" },
    { name: "HTML & CSS", issuer: "freeCodeCamp" },
    { name: "Red Hat Certified", issuer: "Red Hat" },
    { name: "AWS Cloud Practitioner", issuer: "Amazon Web Services" },
  ];

  return (
    <>
      {/* Google Fonts */}
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link
        href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700;800&family=Inter:wght@400;500;600&display=swap"
        rel="stylesheet"
      />

      <style>{`
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; }
        body {
          background: #050B18;
          color: #F1F5F9;
          min-height: 100vh;
          overflow-x: hidden;
        }
        ::selection { background: rgba(99,102,241,0.3); color: #F1F5F9; }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: #050B18; }
        ::-webkit-scrollbar-thumb { background: #4F46E5; border-radius: 3px; }
        @keyframes floatOrb {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-20px) rotate(10deg); }
        }
        @keyframes fadeSlideUp {
          from { opacity: 0; transform: translateY(30px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.4; }
        }
        @keyframes spin3d {
          0% { transform: rotateX(0deg) rotateY(0deg); }
          100% { transform: rotateX(360deg) rotateY(360deg); }
        }
        .hero-content { animation: fadeSlideUp 0.8s ease forwards; }
        .hero-content-delay { animation: fadeSlideUp 0.8s ease 0.2s forwards; opacity: 0; }
        .hero-content-delay2 { animation: fadeSlideUp 0.8s ease 0.4s forwards; opacity: 0; }
        .section-reveal {
          opacity: 0;
          transform: translateY(24px);
          transition: opacity 0.7s ease, transform 0.7s ease;
        }
        .section-reveal.visible {
          opacity: 1;
          transform: translateY(0);
        }
        .status-dot {
          width: 8px; height: 8px;
          border-radius: 50%;
          background: #10B981;
          animation: pulse 2s infinite;
          display: inline-block;
        }
        @media (max-width: 768px) {
          .desktop-nav { display: none !important; }
          .hamburger { display: flex !important; }
          .form-grid { grid-template-columns: 1fr !important; }
          .contact-grid { grid-template-columns: 1fr !important; }
          .about-grid { grid-template-columns: 1fr !important; }
        }
      `}</style>

      <Navbar active={activeSection} />

      {/* ── HERO ──────────────────────────────────────────────────────────── */}
      <section
        id="home"
        style={{
          position: "relative",
          minHeight: "100vh",
          display: "flex",
          alignItems: "center",
          padding: "0 5vw",
          overflow: "hidden",
        }}
      >
        <ParticleCanvas />

        {/* Background orbs */}
        <FloatingOrb size="400px" top="-100px" left="-100px" delay="0s" color="#4F46E5" />
        <FloatingOrb size="300px" top="60%" left="70%" delay="2s" color="#06B6D4" />
        <FloatingOrb size="200px" top="20%" left="80%" delay="1s" color="#7C3AED" />

        {/* Rotating 3D cube wireframe */}
        <div
          style={{
            position: "absolute",
            right: "8vw",
            top: "50%",
            transform: "translateY(-50%)",
            width: "180px",
            height: "180px",
            perspective: "600px",
            display: "none",
          }}
          className="hero-cube"
        >
          <div
            style={{
              width: "100%",
              height: "100%",
              transformStyle: "preserve-3d",
              animation: "spin3d 12s linear infinite",
              position: "relative",
            }}
          >
            {["front", "back", "left", "right", "top", "bottom"].map((face, i) => {
              const transforms = {
                front: "translateZ(90px)",
                back: "rotateY(180deg) translateZ(90px)",
                left: "rotateY(-90deg) translateZ(90px)",
                right: "rotateY(90deg) translateZ(90px)",
                top: "rotateX(90deg) translateZ(90px)",
                bottom: "rotateX(-90deg) translateZ(90px)",
              };
              return (
                <div
                  key={face}
                  style={{
                    position: "absolute",
                    width: "180px",
                    height: "180px",
                    border: "1px solid rgba(99,102,241,0.3)",
                    background: "rgba(79,70,229,0.03)",
                    transform: transforms[face],
                  }}
                />
              );
            })}
          </div>
        </div>

        <div style={{ position: "relative", zIndex: 2, maxWidth: "760px" }}>
          <div className="hero-content" style={{ marginBottom: "16px", display: "flex", alignItems: "center", gap: "10px" }}>
            <span className="status-dot" />
            <span
              style={{
                fontFamily: "'Space Grotesk', sans-serif",
                fontSize: "13px",
                color: "#64748B",
                letterSpacing: "0.04em",
              }}
            >
              Available for opportunities · 2nd Year B.Tech CS
            </span>
          </div>

          <h1
            className="hero-content"
            style={{
              fontFamily: "'Space Grotesk', sans-serif",
              fontSize: "clamp(36px, 6vw, 72px)",
              fontWeight: 800,
              lineHeight: 1.08,
              marginBottom: "12px",
              letterSpacing: "-0.03em",
            }}
          >
            Hi, I'm{" "}
            <span
              style={{
                background: "linear-gradient(135deg, #818CF8, #06B6D4)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}
            >
              Garv Tanwar
            </span>
            .
          </h1>

          <h2
            className="hero-content"
            style={{
              fontFamily: "'Space Grotesk', sans-serif",
              fontSize: "clamp(24px, 4vw, 48px)",
              fontWeight: 700,
              color: "#475569",
              lineHeight: 1.15,
              marginBottom: "24px",
              letterSpacing: "-0.02em",
              minHeight: "1.2em",
            }}
          >
            I build things as a{" "}
            <span style={{ color: "#6366F1" }}>
              {typedText}
              <span style={{ opacity: cursorVisible ? 1 : 0 }}>|</span>
            </span>
          </h2>

          <p
            className="hero-content-delay"
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: "clamp(15px, 2vw, 17px)",
              color: "#64748B",
              lineHeight: 1.75,
              maxWidth: "560px",
              marginBottom: "36px",
            }}
          >
            Software & web developer in my second year of B.Tech CS. I write clean
            code, ship real projects, and care about the details — from the first line
            of HTML to a working deployment.
          </p>

          <div
            className="hero-content-delay2"
            style={{ display: "flex", flexWrap: "wrap", gap: "14px" }}
          >
            <MagneticBtn
              href="#projects"
              onClick={(e) => {
                e.preventDefault();
                document.getElementById("projects")?.scrollIntoView({ behavior: "smooth" });
              }}
              variant="primary"
            >
              View My Work ↓
            </MagneticBtn>
            <MagneticBtn href="/resume.pdf" variant="outline">
              Download Resume ↗
            </MagneticBtn>
          </div>

          {/* Social links */}
          <div
            className="hero-content-delay2"
            style={{ display: "flex", gap: "20px", marginTop: "40px" }}
          >
            {[
              { href: "mailto:garvt957@gmail.com", label: "Email", icon: "✉" },
              { href: "https://www.linkedin.com/in/garv-tanwar-2013443aa/", label: "LinkedIn", icon: "in" },
              { href: "https://github.com/Garvvv9887", label: "GitHub", icon: "⌥" },
            ].map((s) => (
              <a
                key={s.label}
                href={s.href}
                target={s.href.startsWith("http") ? "_blank" : undefined}
                rel="noopener noreferrer"
                title={s.label}
                style={{
                  width: "40px",
                  height: "40px",
                  borderRadius: "10px",
                  border: "1px solid rgba(99,102,241,0.25)",
                  background: "rgba(79,70,229,0.08)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  color: "#A5B4FC",
                  textDecoration: "none",
                  fontFamily: "'Space Grotesk', sans-serif",
                  fontWeight: 700,
                  fontSize: "14px",
                  transition: "all 0.2s",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = "rgba(79,70,229,0.2)";
                  e.currentTarget.style.borderColor = "rgba(99,102,241,0.5)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = "rgba(79,70,229,0.08)";
                  e.currentTarget.style.borderColor = "rgba(99,102,241,0.25)";
                }}
              >
                {s.icon}
              </a>
            ))}
          </div>
        </div>

        {/* Scroll cue */}
        <div
          style={{
            position: "absolute",
            bottom: "32px",
            left: "50%",
            transform: "translateX(-50%)",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: "8px",
            color: "#334155",
            fontFamily: "'Space Grotesk', sans-serif",
            fontSize: "11px",
            letterSpacing: "0.1em",
            textTransform: "uppercase",
          }}
        >
          <div
            style={{
              width: "1px",
              height: "40px",
              background: "linear-gradient(to bottom, transparent, #4F46E5)",
              animation: "pulse 2s infinite",
            }}
          />
          scroll
        </div>
      </section>

      {/* ── ABOUT ─────────────────────────────────────────────────────────── */}
      <section
        id="about"
        style={{
          padding: "120px 5vw",
          position: "relative",
        }}
      >
        <div
          style={{
            maxWidth: "1100px",
            margin: "0 auto",
          }}
        >
          <SectionHeading label="Who I Am" title="About Me" />

          <div
            className="about-grid"
            style={{
              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              gap: "64px",
              alignItems: "start",
            }}
          >
            <div>
              <p
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontSize: "16px",
                  lineHeight: 1.8,
                  color: "#94A3B8",
                  marginBottom: "20px",
                }}
              >
                I'm <strong style={{ color: "#F1F5F9" }}>Garv Tanwar</strong>, a
                second-year B.Tech Computer Science student with a genuine interest
                in building software that works — not just demos that look good. I
                started with the fundamentals and kept going: picking up new tools,
                shipping real projects, and learning what it actually takes to go
                from an idea to something live on the internet.
              </p>
              <p
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontSize: "16px",
                  lineHeight: 1.8,
                  color: "#94A3B8",
                  marginBottom: "20px",
                }}
              >
                I like clean interfaces, well-structured code, and the process of
                breaking a problem into something solvable. When I'm not coding, I'm
                reading about how things are built or exploring the next thing I want
                to learn.
              </p>
              <p
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontSize: "16px",
                  lineHeight: 1.8,
                  color: "#94A3B8",
                }}
              >
                Currently looking for{" "}
                <span style={{ color: "#818CF8" }}>
                  internships and collaborative projects
                </span>{" "}
                where I can contribute, learn fast, and build something meaningful.
              </p>
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
              {[
                { label: "University", value: "Parul University, Vadodara" },
                { label: "Degree", value: "B.Tech Computer Science & Engineering" },
                { label: "Batch", value: "2025 – 2029" },
                { label: "CGPA", value: "8.50 / 10.0" },
                { label: "Status", value: "Available for Internships" },
                { label: "Location", value: "Vadodara, Gujarat, India" },
              ].map((item) => (
                <div
                  key={item.label}
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    padding: "14px 20px",
                    background: "rgba(15,23,42,0.6)",
                    borderRadius: "10px",
                    border: "1px solid rgba(255,255,255,0.05)",
                  }}
                >
                  <span
                    style={{
                      fontFamily: "'Space Grotesk', sans-serif",
                      fontSize: "13px",
                      fontWeight: 600,
                      color: "#475569",
                      letterSpacing: "0.02em",
                    }}
                  >
                    {item.label}
                  </span>
                  <span
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontSize: "14px",
                      color: "#CBD5E1",
                      textAlign: "right",
                    }}
                  >
                    {item.value}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── SKILLS ────────────────────────────────────────────────────────── */}
      <section
        id="skills"
        style={{
          padding: "100px 5vw",
          background: "rgba(15,23,42,0.4)",
          position: "relative",
        }}
      >
        <div style={{ maxWidth: "1100px", margin: "0 auto" }}>
          <SectionHeading label="What I Work With" title="Skills & Technologies" />

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
              gap: "24px",
            }}
          >
            {skillGroups.map((group) => (
              <div
                key={group.label}
                style={{
                  background: "rgba(15,23,42,0.7)",
                  borderRadius: "16px",
                  padding: "24px",
                  border: "1px solid rgba(255,255,255,0.05)",
                }}
              >
                <p
                  style={{
                    fontFamily: "'Space Grotesk', sans-serif",
                    fontSize: "11px",
                    fontWeight: 700,
                    letterSpacing: "0.12em",
                    color: "#6366F1",
                    textTransform: "uppercase",
                    marginBottom: "16px",
                  }}
                >
                  {group.label}
                </p>
                <div style={{ display: "flex", flexWrap: "wrap", gap: "8px" }}>
                  {group.skills.map((s) => (
                    <SkillPill key={s.label} {...s} />
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Stats row */}
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(3, 1fr)",
              gap: "20px",
              marginTop: "48px",
            }}
          >
            {[
              { num: "5+", label: "Technologies" },
              { num: "2nd", label: "Year B.Tech" },
              { num: "4+", label: "Certifications" },
            ].map((s) => (
              <div
                key={s.label}
                style={{
                  textAlign: "center",
                  padding: "28px",
                  background: "rgba(79,70,229,0.06)",
                  borderRadius: "14px",
                  border: "1px solid rgba(99,102,241,0.15)",
                }}
              >
                <p
                  style={{
                    fontFamily: "'Space Grotesk', sans-serif",
                    fontSize: "clamp(32px, 5vw, 48px)",
                    fontWeight: 800,
                    background: "linear-gradient(135deg, #818CF8, #06B6D4)",
                    WebkitBackgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                    lineHeight: 1,
                    marginBottom: "8px",
                  }}
                >
                  {s.num}
                </p>
                <p
                  style={{
                    fontFamily: "'Inter', sans-serif",
                    fontSize: "14px",
                    color: "#64748B",
                  }}
                >
                  {s.label}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── PROJECTS ──────────────────────────────────────────────────────── */}
      <section id="projects" style={{ padding: "100px 5vw" }}>
        <div style={{ maxWidth: "1100px", margin: "0 auto" }}>
          <SectionHeading label="What I've Built" title="Projects" />

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
              gap: "24px",
            }}
          >
            {projects.map((p, i) => (
              <ProjectCard key={p.title} {...p} index={i} />
            ))}
          </div>

          <div style={{ marginTop: "40px", textAlign: "center" }}>
            <MagneticBtn href="https://github.com/Garvvv9887" variant="outline">
              View All on GitHub ↗
            </MagneticBtn>
          </div>
        </div>
      </section>

      {/* ── EDUCATION ─────────────────────────────────────────────────────── */}
      <section
        id="education"
        style={{
          padding: "100px 5vw",
          background: "rgba(15,23,42,0.4)",
        }}
      >
        <div style={{ maxWidth: "1100px", margin: "0 auto" }}>
          <SectionHeading label="My Background" title="Education & Certifications" />

          <div style={{ display: "grid", gap: "20px" }}>
            {/* Education card */}
            <TiltCard
              style={{
                background: "rgba(15,23,42,0.8)",
                borderRadius: "16px",
                padding: "32px",
                border: "1px solid rgba(99,102,241,0.2)",
                position: "relative",
                overflow: "hidden",
              }}
            >
              <div
                style={{
                  position: "absolute",
                  top: 0,
                  left: 0,
                  bottom: 0,
                  width: "3px",
                  background: "linear-gradient(180deg, #4F46E5, #06B6D4)",
                }}
              />
              <div
                style={{
                  paddingLeft: "20px",
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "start",
                  flexWrap: "wrap",
                  gap: "16px",
                }}
              >
                <div>
                  <p
                    style={{
                      fontFamily: "'Space Grotesk', sans-serif",
                      fontSize: "12px",
                      fontWeight: 600,
                      color: "#6366F1",
                      letterSpacing: "0.08em",
                      marginBottom: "8px",
                    }}
                  >
                    PARUL UNIVERSITY · VADODARA, GUJARAT
                  </p>
                  <h3
                    style={{
                      fontFamily: "'Space Grotesk', sans-serif",
                      fontSize: "20px",
                      fontWeight: 700,
                      color: "#F1F5F9",
                      marginBottom: "6px",
                    }}
                  >
                    B.Tech — Computer Science & Engineering
                  </h3>
                  <p
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontSize: "14px",
                      color: "#64748B",
                    }}
                  >
                    2025 – 2029 · Currently in 2nd Year
                  </p>
                </div>
                <div
                  style={{
                    background: "rgba(79,70,229,0.12)",
                    border: "1px solid rgba(99,102,241,0.3)",
                    borderRadius: "10px",
                    padding: "12px 20px",
                    textAlign: "center",
                  }}
                >
                  <p
                    style={{
                      fontFamily: "'Space Grotesk', sans-serif",
                      fontSize: "26px",
                      fontWeight: 800,
                      color: "#818CF8",
                      lineHeight: 1,
                    }}
                  >
                    8.50
                  </p>
                  <p
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontSize: "11px",
                      color: "#475569",
                      marginTop: "4px",
                    }}
                  >
                    CGPA / 10.0
                  </p>
                </div>
              </div>
            </TiltCard>

            {/* Certifications */}
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
                gap: "16px",
              }}
            >
              {certs.map((cert) => (
                <div
                  key={cert.name}
                  style={{
                    background: "rgba(15,23,42,0.7)",
                    borderRadius: "12px",
                    padding: "20px",
                    border: "1px solid rgba(255,255,255,0.05)",
                    display: "flex",
                    gap: "12px",
                    alignItems: "center",
                  }}
                >
                  <div
                    style={{
                      width: "36px",
                      height: "36px",
                      borderRadius: "8px",
                      background: "rgba(6,182,212,0.12)",
                      border: "1px solid rgba(6,182,212,0.25)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      fontSize: "16px",
                      flexShrink: 0,
                    }}
                  >
                    🎖
                  </div>
                  <div>
                    <p
                      style={{
                        fontFamily: "'Space Grotesk', sans-serif",
                        fontSize: "13px",
                        fontWeight: 600,
                        color: "#CBD5E1",
                        marginBottom: "2px",
                      }}
                    >
                      {cert.name}
                    </p>
                    <p
                      style={{
                        fontFamily: "'Inter', sans-serif",
                        fontSize: "12px",
                        color: "#475569",
                      }}
                    >
                      {cert.issuer}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── CONTACT ───────────────────────────────────────────────────────── */}
      <section id="contact" style={{ padding: "100px 5vw 140px" }}>
        <div style={{ maxWidth: "1100px", margin: "0 auto" }}>
          <SectionHeading label="Get In Touch" title="Let's Build Something Together" />

          <p
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: "16px",
              color: "#64748B",
              lineHeight: 1.75,
              maxWidth: "520px",
              marginBottom: "56px",
              marginTop: "-24px",
            }}
          >
            Open to internships, freelance work, and collaborative projects. If you
            have an idea or an opportunity, I'd love to hear about it.
          </p>

          <div
            className="contact-grid"
            style={{
              display: "grid",
              gridTemplateColumns: "1fr 1.4fr",
              gap: "48px",
              alignItems: "start",
            }}
          >
            <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
              {[
                {
                  icon: "✉",
                  label: "Email",
                  value: "garvt957@gmail.com",
                  href: "mailto:garvt957@gmail.com",
                },
                {
                  icon: "in",
                  label: "LinkedIn",
                  value: "garv-tanwar",
                  href: "https://www.linkedin.com/in/garv-tanwar-2013443aa/",
                },
                {
                  icon: "⌥",
                  label: "GitHub",
                  value: "Garvvv9887",
                  href: "https://github.com/Garvvv9887",
                },
              ].map((c) => (
                <a
                  key={c.label}
                  href={c.href}
                  target={c.href.startsWith("http") ? "_blank" : undefined}
                  rel="noopener noreferrer"
                  style={{
                    display: "flex",
                    gap: "16px",
                    alignItems: "center",
                    padding: "18px 20px",
                    background: "rgba(15,23,42,0.7)",
                    borderRadius: "12px",
                    border: "1px solid rgba(255,255,255,0.05)",
                    textDecoration: "none",
                    transition: "border-color 0.2s, background 0.2s",
                    cursor: "pointer",
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.borderColor = "rgba(99,102,241,0.3)";
                    e.currentTarget.style.background = "rgba(79,70,229,0.08)";
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.borderColor = "rgba(255,255,255,0.05)";
                    e.currentTarget.style.background = "rgba(15,23,42,0.7)";
                  }}
                >
                  <div
                    style={{
                      width: "40px",
                      height: "40px",
                      borderRadius: "10px",
                      background: "rgba(79,70,229,0.12)",
                      border: "1px solid rgba(99,102,241,0.2)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      fontFamily: "'Space Grotesk', sans-serif",
                      fontWeight: 700,
                      fontSize: "15px",
                      color: "#818CF8",
                      flexShrink: 0,
                    }}
                  >
                    {c.icon}
                  </div>
                  <div>
                    <p
                      style={{
                        fontFamily: "'Space Grotesk', sans-serif",
                        fontSize: "12px",
                        fontWeight: 600,
                        color: "#475569",
                        marginBottom: "2px",
                        textTransform: "uppercase",
                        letterSpacing: "0.06em",
                      }}
                    >
                      {c.label}
                    </p>
                    <p
                      style={{
                        fontFamily: "'Inter', sans-serif",
                        fontSize: "14px",
                        color: "#CBD5E1",
                      }}
                    >
                      {c.value}
                    </p>
                  </div>
                </a>
              ))}
            </div>

            <div
              style={{
                background: "rgba(15,23,42,0.7)",
                borderRadius: "16px",
                padding: "32px",
                border: "1px solid rgba(255,255,255,0.05)",
              }}
            >
              <ContactForm />
            </div>
          </div>
        </div>
      </section>

      {/* ── FOOTER ────────────────────────────────────────────────────────── */}
      <footer
        style={{
          borderTop: "1px solid rgba(255,255,255,0.05)",
          padding: "28px 5vw",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          flexWrap: "wrap",
          gap: "12px",
        }}
      >
        <span
          style={{
            fontFamily: "'Space Grotesk', sans-serif",
            fontWeight: 800,
            fontSize: "16px",
            color: "#334155",
          }}
        >
          GT<span style={{ color: "#6366F1" }}>.</span>
        </span>
        <p
          style={{
            fontFamily: "'Inter', sans-serif",
            fontSize: "13px",
            color: "#334155",
          }}
        >
          © 2025 Garv Tanwar · Built with React
        </p>
      </footer>
    </>
  );
}
